import pandas as pd, numpy as np, json
x=pd.read_parquet("copy_decisions.parquet"); df=pd.read_parquet("sample.parquet")
rng=np.random.default_rng(0)
def ci(v):
    b=rng.choice(v,(1000,len(v))).mean(1); return [round(float(np.percentile(b,2.5))*100,2),round(float(np.percentile(b,97.5))*100,2)]
out={}
for g in ["top10_ctrl","top10_top300","random_all"]:
    o=df[(df.grp==g)]; net=(o.first_token_won/(o.first_price*1.015)-1).values
    r={"source_own_fill":dict(n=len(o),win=round(o.first_token_won.mean()*100,2),net=round(net.mean()*100,2),ci=ci(net))}
    for d in [60,180,300]:
        s=x[(x.grp==g)&(x.d==d)]; ok=s.exec&(s.p>=0.05)&(s.p<=0.95); e=s[ok]
        r[f"delay_{d}s"]=dict(signals=len(s),executable_pct=round(ok.mean()*100,1),closed_before_pct=round(s.closed.mean()*100,1),
            win=round(e.won.mean()*100,2),price_worse_by=round((e.p-e.src_fill).mean()*100,2),gross=round(e.gross.mean()*100,2),net=round(e.net.mean()*100,2),ci=ci(e.net.values))
    out[g]=r
json.dump(out,open("delay_result_final.json","w"),indent=1)
for k,r in out.items():
    print(k); [print("  ",kk,v) for kk,v in r.items()]
