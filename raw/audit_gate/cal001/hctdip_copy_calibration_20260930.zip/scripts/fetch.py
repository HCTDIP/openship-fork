import pandas as pd, httpx, asyncio, json, os
df=pd.read_parquet("sample.parquet")
done=set()
if os.path.exists("ph.jsonl"):
    for l in open("ph.jsonl"): done.add(json.loads(l)["k"])
async def main():
    sem=asyncio.Semaphore(24); f=open("ph.jsonl","a")
    async with httpx.AsyncClient(headers={"User-Agent":"Mozilla/5.0"},timeout=30) as h:
        async def one(i,r):
            k=f"{i}"
            if k in done: return
            t=int(r.first_ts.timestamp())
            async with sem:
                for a in range(4):
                    try:
                        x=await h.get("https://clob.polymarket.com/prices-history",params={"market":r.asset,"startTs":t-300,"endTs":t+900,"fidelity":1})
                        if x.status_code==200: f.write(json.dumps({"k":k,"h":x.json().get("history",[])})+"\n"); return
                        await asyncio.sleep(2*(a+1))
                    except Exception: await asyncio.sleep(2*(a+1))
                f.write(json.dumps({"k":k,"h":None,"err":1})+"\n")
        await asyncio.gather(*[one(i,r) for i,r in df.iterrows()])
    f.close()
asyncio.run(main()); open("fetch.done","w").write("ok")
