import pandas as pd, numpy as np, json, bisect
df=pd.read_parquet("sample.parquet")
H={}
for l in open("ph.jsonl"):
    d=json.loads(l); H[int(d["k"])]=d["h"]
COST=0.015; DEL=[0,60,180,300]
def px_at(h,t):
    if not h: return np.nan
    ts=[x["t"] for x in h]; i=bisect.bisect_right(ts,t)-1
    if i>=0 and t-ts[i]<=120: return h[i]["p"]
    if i+1<len(ts) and ts[i+1]-t<=60: return h[i+1]["p"]
    return np.nan
rows=[]
for i,r in df.iterrows():
    h=H.get(i); t=int(r.first_ts.timestamp()); ct=r.ct.timestamp() if pd.notna(r.ct) else np.inf
    for d in DEL:
        p=px_at(h,t+d); closed = ct <= t+d
        rows.append(dict(i=i,grp=r.grp,d=d,src_fill=r.first_price,p=p,closed=closed,won=r.first_token_won,cat=r["cat"],hrs=r.hrs_to_res))
x=pd.DataFrame(rows)
x["exec"]=x.p.notna() & (~x.closed) & (x.p>0) & (x.p<1)
x["gross"]=np.where(x.exec, x.won/x.p-1, np.nan)
x["net"]=np.where(x.exec, x.won/(x.p*(1+COST))-1, np.nan)
# own-fill reference (delay 0 at the source's own price)
own=df.assign(gross=df.first_token_won/df.first_price-1, net=df.first_token_won/(df.first_price*(1+COST))-1)
def ci(v):
    v=v[~np.isnan(v)]; b=np.random.default_rng(0).choice(v,(500,len(v))).mean(1); return [round(float(np.percentile(b,2.5)),4),round(float(np.percentile(b,97.5)),4)]
res={}
for g in ["top10_ctrl","top10_top300","random_all"]:
    o=own[own.grp==g]; res[g]={"n":int(len(o)),"source_own_fill":{"win":round(float(o.first_token_won.mean()),4),"gross":round(float(o.gross.mean()),4),"net_1.5%":round(float(o.net.mean()),4),"net_ci95":ci(o.net.values)}}
    for d in DEL:
        s=x[(x.grp==g)&(x.d==d)]; e=s[s.exec]
        res[g][f"copy_{d}s"]={"executable":round(float(s.exec.mean()),4),"closed_before":round(float(s.closed.mean()),4),"no_price":round(float(s.p.isna().mean()),4),
          "win":round(float(e.won.mean()),4),"avg_price":round(float(e.p.mean()),4),"gross":round(float(e.gross.mean()),4),"net_1.5%":round(float(e.net.mean()),4),"net_ci95":ci(e.net.values)}
# by category for top10_ctrl at 60s
res["top10_ctrl_by_cat_60s"]={c:{"n":int(len(e)),"net":round(float(e.net.mean()),4)} for c,e in x[(x.grp=="top10_ctrl")&(x.d==60)&x.exec].groupby("cat")}
json.dump(res,open("delay_result.json","w"),indent=1); x.to_parquet("copy_decisions.parquet")
print(json.dumps(res,indent=1))
