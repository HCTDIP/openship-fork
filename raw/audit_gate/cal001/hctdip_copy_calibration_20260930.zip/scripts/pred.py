import duckdb, numpy as np, lightgbm as lgb, pandas as pd, time
src=open("/work/temp/train/train.py").read().split("F_ALL=")[0].replace('duckdb.connect("train.duckdb")','duckdb.connect("/work/temp/train/train.duckdb",read_only=True)')
src=src.replace("SELECT r.wallet, r.src,","SELECT r.wallet, r.src, r.conditionId, r.first_ts, r.first_side, r.first_token_won,")
exec(src)
F=["first_price","buy","lusd","hrs_to_res","cat","p_n","p_win","p_pnl","p_roi","p_avgpx","p_crypto","p_hold"]
va=ds("2026-09-01","2026-10-01","2026-09-01")
m=lgb.Booster(model_file="/work/temp/train/model_v1_roi.txt")
X=np.column_stack([np.asarray(va[k],float) for k in F])
t=time.perf_counter(); s=m.predict(X); el=time.perf_counter()-t
df=pd.DataFrame({k:va[k] for k in ["wallet","src","conditionId","first_ts","first_side","first_token_won","first_price","hrs_to_res","cat","pnl","buy_usdc","label"]}); df["score"]=s
df["top10"]=df.score>=df.score.quantile(0.9)
print("batch infer",len(df),"rows",round(el,3),"s")
# single-row latency
lat=[]
for i in range(2000):
    x=X[i:i+1]; t=time.perf_counter(); m.predict(x); lat.append((time.perf_counter()-t)*1000)
lat=np.array(lat); print("single ms mean",lat.mean(),"p95",np.percentile(lat,95),"p99",np.percentile(lat,99),"max",lat.max())
np.save("infer_ms.npy",lat)
df.to_parquet("val_pred.parquet"); print(df.top10.sum(), df[df.top10].first_side.value_counts().to_dict(), df[df.top10].src.value_counts().to_dict())
