import httpx,time,json,numpy as np
h=httpx.Client(headers={"User-Agent":"Mozilla/5.0"},timeout=20)
lags=[];rt=[]
for i in range(40):
    t0=time.time(); x=h.get("https://data-api.polymarket.com/trades",params={"limit":100}); t1=time.time()
    rt.append(t1-t0); ts=max(d["timestamp"] for d in x.json()); lags.append(t1-ts)
    time.sleep(1.5)
r={"api_roundtrip_s":{"mean":np.mean(rt),"p95":np.percentile(rt,95),"p99":np.percentile(rt,99),"max":max(rt)},
   "feed_freshness_s(now - newest trade ts)":{"mean":np.mean(lags),"p95":np.percentile(lags,95),"p99":np.percentile(lags,99),"max":max(lags),"min":min(lags)},"n":40}
json.dump(r,open("lag.json","w"),indent=1); print(json.dumps(r,indent=1))
