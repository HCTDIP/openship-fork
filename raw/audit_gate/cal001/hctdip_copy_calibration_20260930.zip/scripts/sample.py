import duckdb, pandas as pd
df=pd.read_parquet("val_pred.parquet"); df=df[df.first_side=="BUY"]
t=df[df.top10]
s=pd.concat([t[t.src=="ctrl"].sample(12000,random_state=1).assign(grp="top10_ctrl"),
             t[t.src=="top300"].sample(8000,random_state=1).assign(grp="top10_top300"),
             df.sample(8000,random_state=2).assign(grp="random_all")])
c=duckdb.connect("/work/temp/train/train.duckdb",read_only=True); c.register("s",s)
out=c.execute("""SELECT s.*, (SELECT arg_min(asset,time_utc) FROM tr WHERE tr.wallet=s.wallet AND tr.conditionId=s.conditionId AND tr.side='BUY') asset,
  (SELECT any_value(ct) FROM tr WHERE tr.conditionId=s.conditionId) ct FROM s""").df()
out.to_parquet("sample.parquet"); print(out.grp.value_counts(), out.asset.isna().sum())
